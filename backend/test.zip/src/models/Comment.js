import mongoose from 'mongoose';

const CommentSchema = new mongoose.Schema({
    pollId: {
        type: String,
        required: true,
    },
    text: {
        type: String,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

export default mongoose.model('Comment', CommentSchema);