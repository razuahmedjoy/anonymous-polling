import { nanoid } from 'nanoid';

export default () => nanoid(8);